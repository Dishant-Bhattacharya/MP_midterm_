package com.example.midterm

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import com.example.quiz1.R
import com.google.android.material.navigation.NavigationBarView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val edtxt1: EditText = findViewById(R.id.ednum1)
        val edtxt2: EditText = findViewById(R.id.ednum2)
        val resultTV: TextView = findViewById(R.id.textResult)

        val buttonAdd: Button = findViewById(R.id.btAdd)
        val buttonSubtract: Button = findViewById(R.id.btSubtract)
        val buttonMultiply: Button = findViewById(R.id.btMultiply)
        val buttonDivide: Button = findViewById(R.id.btDivide)

        buttonAdd.setOnClickListener {
            val num1 = edtxt1.text.toString()
            val num2 = edtxt2.text.toString()

            if (num1.isEmpty() || num2.isEmpty()) {
                Toast.makeText(this@MainActivity, "Enter valid numbers", Toast.LENGTH_SHORT).show()
            } else {
                val x: Int = num1.toInt()
                val y: Int = num2.toInt()
                resultTV.text = sum(x, y).toString()
            }
        }

        buttonSubtract.setOnClickListener {
            val num1 = edtxt1.text.toString()
            val num2 = edtxt2.text.toString()

            if (num1.isEmpty() || num2.isEmpty()) {
                Toast.makeText(this@MainActivity, "Enter valid numbers", Toast.LENGTH_SHORT).show()
            } else {
                val x: Int = num1.toInt()
                val y: Int = num2.toInt()
                resultTV.text = subtract(x, y).toString()
            }
        }

        buttonMultiply.setOnClickListener {
            val num1 = edtxt1.text.toString()
            val num2 = edtxt2.text.toString()

            if (num1.isEmpty() || num2.isEmpty()) {
                Toast.makeText(this@MainActivity, "Enter valid numbers", Toast.LENGTH_SHORT).show()
            } else {
                val x: Int = num1.toInt()
                val y: Int = num2.toInt()
                resultTV.text = multiply(x, y).toString()
            }
        }

        buttonDivide.setOnClickListener {
            val num1 = edtxt1.text.toString()
            val num2 = edtxt2.text.toString()

            if (num1.isEmpty() || num2.isEmpty()) {
                Toast.makeText(this@MainActivity, "Enter valid numbers", Toast.LENGTH_SHORT).show()
            } else {
                val x: Int = num1.toInt()
                val y: Int = num2.toInt()

                if (y == 0) {
                    Toast.makeText(this@MainActivity, "Cannot divide by zero", Toast.LENGTH_SHORT).show()
                } else {
                    resultTV.text = divide(x, y).toString()
                }
            }
        }
    }

    // Sum function
    private fun sum(a: Int, b: Int): Int {
        return a + b
    }

    // Subtract function
    private fun subtract(a: Int, b: Int): Int {
        return a - b
    }

    // Multiply function
    private fun multiply(a: Int, b: Int): Int {
        return a * b
    }

    // Divide function
    private fun divide(a: Int, b: Int): Int {
        return a / b
    }
}