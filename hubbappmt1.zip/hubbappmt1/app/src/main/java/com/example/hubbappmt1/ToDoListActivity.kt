package com.example.hubapp

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.hubbappmt1.R

class ToDoListActivity : AppCompatActivity() {

    private val tasks = mutableListOf<String>()
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_to_do_list)

        val initialData = intent.getStringExtra("initialData")
        val tvInitialData = findViewById<TextView>(R.id.tvInitialData)
        tvInitialData.text = initialData

        val spinnerPriority = findViewById<Spinner>(R.id.spinnerPriority)
        ArrayAdapter.createFromResource(
            this,
            R.array.priority_levels,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinnerPriority.adapter = adapter
        }

        val etTask = findViewById<EditText>(R.id.etTask)
        val btnAddTask = findViewById<Button>(R.id.btnAddTask)
        val lvTasks = findViewById<ListView>(R.id.lvTasks)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, tasks)
        lvTasks.adapter = adapter

        btnAddTask.setOnClickListener {
            val task = etTask.text.toString()
            val priority = spinnerPriority.selectedItem.toString()
            if (task.isNotEmpty()) {
                tasks.add("$task (Priority: $priority)")
                adapter.notifyDataSetChanged()
                etTask.text.clear()
                spinnerPriority.setSelection(1)
            } else {
                Toast.makeText(this, "Please enter a task", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
