package com.example.hubapp

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.hubbappmt1.R

class UnitConverterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_unit_converter)

        val initialData = intent.getStringExtra("initialData")
        val tvInitialData = findViewById<TextView>(R.id.tvInitialData)
        tvInitialData.text = initialData

        val spinnerConversionType = findViewById<android.widget.Spinner>(R.id.spinnerConversionType)
        ArrayAdapter.createFromResource(
            this,
            R.array.conversion_types,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinnerConversionType.adapter = adapter
        }
    }
}
