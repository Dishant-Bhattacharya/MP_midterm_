package com.example.hubapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.hubbappmt1.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnLaunchUnitConverter = findViewById<Button>(R.id.btnLaunchUnitConverter)
        val btnLaunchToDoList = findViewById<Button>(R.id.btnLaunchToDoList)

        btnLaunchUnitConverter.setOnClickListener {
            val intent = Intent(this, activity_unit_coverter::class.java)
            intent.putExtra("initialData", "Welcome to Unit Converter")
            startActivity(intent)
        }

        btnLaunchToDoList.setOnClickListener {
            val intent = Intent(this, ToDoListActivity::class.java)
            intent.putExtra("initialData", "Welcome to To-Do List")
            startActivity(intent)
        }
    }
}

class activity_unit_coverter {

}
